<script>
function myFunction() {
    var x = document.getElementById("myFile");
    x.disabled = true;
}
</script>